package Algo2_Lab_Work_Sem1;

public class DemoFami {
    public int var1;
    protected int var2;
    int var3;
    @SuppressWarnings("unused")
    private int var4;

    public static int var5;
    protected static int var6;
    static int var7;
    @SuppressWarnings("unused")
    private static int var8;

    public void met1() {}
    protected void met2() {}
    void met3() {}
    @SuppressWarnings("unused")
    private void met4() {}

    public static void met5() {}
    protected static void met6() {}
    static void met7() {}
    @SuppressWarnings("unused")
    private static void met8() {}
}
